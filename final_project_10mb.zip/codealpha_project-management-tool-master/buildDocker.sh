docker build --network=host -t devaslanphp/helper:latest .
