# Security Policy

## Supported Versions

| Version | Supported |
| ------- | ------------------ |
| 1.x | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability within Help Desk application, please email me via [eloufirhatim@gmail.com](mailto:eloufirhatim@gmail.com). All security vulnerabilities will be promptly addressed.
